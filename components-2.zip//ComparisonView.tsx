import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { FileText, Plus, Minus, RotateCcw, CheckCircle, XCircle, AlertTriangle, Loader2 } from "lucide-react";
import { ClauseSenseAPI } from "../utils/api";

interface ComparisonDifference {
  type: "added" | "removed" | "changed";
  clause: string;
  page: number;
  description: string;
  impact: "low" | "medium" | "high";
}

interface ComparisonData {
  documentA: string;
  documentB: string;
  differences: ComparisonDifference[];
  verdict: {
    recommendation: string;
    reasoning: string;
    favorability: "A" | "B" | "Equal";
  };
}

interface Document {
  id: string;
  name: string;
}

export function ComparisonView() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [selectedDocA, setSelectedDocA] = useState<string>("");
  const [selectedDocB, setSelectedDocB] = useState<string>("");
  const [comparisonData, setComparisonData] = useState<ComparisonData | null>(null);
  const [isComparing, setIsComparing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setIsLoading(true);
      const response = await ClauseSenseAPI.getDocuments();
      const processedDocs = (response.documents || [])
        .filter((doc: any) => doc.status === 'processed')
        .map((doc: any) => ({
          id: doc.id,
          name: doc.name
        }));
      setDocuments(processedDocs);
      
      // Auto-select first two documents if available
      if (processedDocs.length >= 2) {
        setSelectedDocA(processedDocs[0].id);
        setSelectedDocB(processedDocs[1].id);
      }
    } catch (error) {
      console.error('Error loading documents:', error);
      setError('Failed to load documents for comparison.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCompare = async () => {
    if (!selectedDocA || !selectedDocB || selectedDocA === selectedDocB) {
      setError('Please select two different documents to compare.');
      return;
    }

    setIsComparing(true);
    setError(null);

    try {
      const response = await ClauseSenseAPI.compareDocuments(selectedDocA, selectedDocB);
      
      setComparisonData({
        documentA: response.documentA,
        documentB: response.documentB,
        differences: response.differences,
        verdict: response.verdict
      });
    } catch (error) {
      console.error('Comparison error:', error);
      setError(error instanceof Error ? error.message : 'Failed to compare documents. Please try again.');
    } finally {
      setIsComparing(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "added": return <Plus className="w-4 h-4" />;
      case "removed": return <Minus className="w-4 h-4" />;
      case "changed": return <RotateCcw className="w-4 h-4" />;
      default: return null;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "added": return "text-green-600 bg-green-50 border-green-200";
      case "removed": return "text-red-600 bg-red-50 border-red-200";
      case "changed": return "text-yellow-600 bg-yellow-50 border-yellow-200";
      default: return "text-gray-600 bg-gray-50 border-gray-200";
    }
  };

  const getImpactBadge = (impact: string) => {
    switch (impact) {
      case "high": return <Badge variant="destructive">High Impact</Badge>;
      case "medium": return <Badge variant="secondary">Medium Impact</Badge>;
      case "low": return <Badge variant="outline">Low Impact</Badge>;
      default: return <Badge variant="outline">Unknown</Badge>;
    }
  };

  const getVerdictIcon = (favorability: string) => {
    switch (favorability) {
      case "A": return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "B": return <CheckCircle className="w-5 h-5 text-blue-600" />;
      case "Equal": return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      default: return <XCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-12 h-12 mx-auto mb-4 animate-spin text-primary" />
          <h3 className="text-lg font-medium mb-2">Loading Documents</h3>
          <p className="text-gray-600">
            Preparing documents for comparison...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-2xl font-medium text-gray-900 mb-2">
          Document Comparison
        </h1>
        <p className="text-gray-600">
          Compare two contracts to identify key differences and determine which is more favorable
        </p>
      </div>

      {/* Error Display */}
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <span className="text-red-800 text-sm">{error}</span>
        </div>
      )}

      {/* Document Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Select Documents to Compare</CardTitle>
          <CardDescription>
            Choose two processed documents to analyze their differences
          </CardDescription>
        </CardHeader>
        <CardContent>
          {documents.length < 2 ? (
            <div className="text-center py-8">
              <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Not Enough Documents
              </h3>
              <p className="text-gray-600">
                You need at least 2 processed documents to perform a comparison. 
                Please upload and process more documents first.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Document A */}
                <div className="space-y-3">
                  <label className="text-sm font-medium">Document A</label>
                  <Select value={selectedDocA} onValueChange={setSelectedDocA}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select first document" />
                    </SelectTrigger>
                    <SelectContent>
                      {documents.map((doc) => (
                        <SelectItem 
                          key={doc.id} 
                          value={doc.id}
                          disabled={doc.id === selectedDocB}
                        >
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4" />
                            {doc.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Document B */}
                <div className="space-y-3">
                  <label className="text-sm font-medium">Document B</label>
                  <Select value={selectedDocB} onValueChange={setSelectedDocB}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select second document" />
                    </SelectTrigger>
                    <SelectContent>
                      {documents.map((doc) => (
                        <SelectItem 
                          key={doc.id} 
                          value={doc.id}
                          disabled={doc.id === selectedDocA}
                        >
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4" />
                            {doc.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-6">
                <Button 
                  onClick={handleCompare}
                  disabled={!selectedDocA || !selectedDocB || selectedDocA === selectedDocB || isComparing}
                  className="bg-primary hover:bg-primary/90"
                >
                  {isComparing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Comparing...
                    </>
                  ) : (
                    'Compare Documents'
                  )}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Comparison Results */}
      {isComparing && (
        <Card>
          <CardContent className="flex items-center justify-center py-12">
            <div className="text-center">
              <div className="w-12 h-12 mx-auto mb-4 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              <p className="text-gray-600">Analyzing document differences...</p>
            </div>
          </CardContent>
        </Card>
      )}

      {comparisonData && !isComparing && (
        <div className="space-y-6">
          {/* Comparison Header */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardContent className="flex items-center gap-3 p-6">
                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">Document A</h3>
                  <p className="text-sm text-gray-600">{comparisonData.documentA}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="flex items-center gap-3 p-6">
                <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">Document B</h3>
                  <p className="text-sm text-gray-600">{comparisonData.documentB}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Differences */}
          <Card>
            <CardHeader>
              <CardTitle>Key Differences</CardTitle>
              <CardDescription>
                Changes between the two documents
              </CardDescription>
            </CardHeader>
            <CardContent>
              {comparisonData.differences.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Significant Differences</h3>
                  <p className="text-gray-600">
                    The documents appear to be very similar with no major differences detected.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {comparisonData.differences.map((diff, index) => (
                    <div 
                      key={index}
                      className={`p-4 rounded-lg border ${getTypeColor(diff.type)}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {getTypeIcon(diff.type)}
                          <span className="font-medium capitalize">{diff.type}</span>
                          <span className="text-sm text-gray-600">
                            {diff.clause}, Page {diff.page}
                          </span>
                        </div>
                        {getImpactBadge(diff.impact)}
                      </div>
                      <p className="text-sm">{diff.description}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Verdict */}
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {getVerdictIcon(comparisonData.verdict.favorability)}
                Which Contract is More Favorable?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <h4 className="font-medium text-primary mb-2">
                    {comparisonData.verdict.recommendation}
                  </h4>
                  <p className="text-sm text-gray-700">
                    {comparisonData.verdict.reasoning}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}