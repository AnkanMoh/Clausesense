import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Send, MessageCircle, Book, Bot, User, Loader2, AlertCircle } from "lucide-react";
import { ClauseSenseAPI } from "../utils/api";

interface QAMessage {
  id: string;
  type: "user" | "assistant";
  content: string;
  citation?: string;
  timestamp: string;
}

interface QAViewProps {
  document: any;
}

const suggestedQuestions = [
  "What are my payment obligations?",
  "How can I modify the scope of work?",
  "What liability protections do I have?",
  "Are there any automatic renewal clauses?"
];

export function QAView({ document }: QAViewProps) {
  const [messages, setMessages] = useState<QAMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (document?.id) {
      loadQAHistory();
    }
  }, [document?.id]);

  const loadQAHistory = async () => {
    if (!document?.id) return;

    setIsLoadingHistory(true);
    try {
      const response = await ClauseSenseAPI.getQAHistory(document.id);
      
      // Convert backend format to frontend format
      const formattedMessages: QAMessage[] = [];
      response.history.forEach((qa: any) => {
        formattedMessages.push({
          id: `user-${qa.id}`,
          type: "user",
          content: qa.question,
          timestamp: qa.timestamp
        });
        formattedMessages.push({
          id: `assistant-${qa.id}`,
          type: "assistant", 
          content: qa.response,
          citation: qa.citation,
          timestamp: qa.timestamp
        });
      });
      
      setMessages(formattedMessages);
    } catch (error) {
      console.error('Error loading Q&A history:', error);
      // Don't show error for missing history, just start fresh
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || !document?.id) return;

    const question = inputValue.trim();
    const userMessage: QAMessage = {
      id: `user-${Date.now()}`,
      type: "user",
      content: question,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);
    setError(null);

    try {
      const response = await ClauseSenseAPI.askQuestion(document.id, question);
      
      const aiMessage: QAMessage = {
        id: `assistant-${response.id}`,
        type: "assistant",
        content: response.response,
        citation: response.citation,
        timestamp: response.timestamp
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error('Error asking question:', error);
      setError(error instanceof Error ? error.message : 'Failed to get response. Please try again.');
      
      // Remove the user message if the request failed
      setMessages(prev => prev.filter(msg => msg.id !== userMessage.id));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    setInputValue(question);
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoadingHistory) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-12 h-12 mx-auto mb-4 animate-spin text-primary" />
          <h3 className="text-lg font-medium mb-2">Loading Conversation</h3>
          <p className="text-gray-600">
            Retrieving your previous questions and answers...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-2xl font-medium text-gray-900 mb-2">
          Ask Questions
        </h1>
        <p className="text-gray-600">
          Get instant answers about your document with citations
        </p>
      </div>

      {/* Error Display */}
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-600" />
          <span className="text-red-800 text-sm">{error}</span>
        </div>
      )}

      {/* Chat Container */}
      <div className="flex-1 flex flex-col">
        {/* Messages */}
        <Card className="flex-1 mb-4">
          <CardContent className="p-6 h-96 overflow-y-auto">
            {messages.length === 0 ? (
              <div className="text-center py-12">
                <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Start a Conversation
                </h3>
                <p className="text-gray-600">
                  Ask questions about your document to get detailed answers with citations.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${
                      message.type === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`flex gap-3 max-w-[80%] ${
                        message.type === "user" ? "flex-row-reverse" : "flex-row"
                      }`}
                    >
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                          message.type === "user"
                            ? "bg-primary text-white"
                            : "bg-gray-100 text-gray-600"
                        }`}
                      >
                        {message.type === "user" ? (
                          <User className="w-4 h-4" />
                        ) : (
                          <Bot className="w-4 h-4" />
                        )}
                      </div>
                      <div
                        className={`rounded-lg p-3 ${
                          message.type === "user"
                            ? "bg-primary text-white"
                            : "bg-gray-50 text-gray-900"
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                        {message.citation && (
                          <div className="flex items-center gap-1 mt-2 pt-2 border-t border-gray-200">
                            <Book className="w-3 h-3 text-gray-500" />
                            <span className="text-xs text-gray-500">
                              {message.citation}
                            </span>
                          </div>
                        )}
                        <div className="text-xs opacity-70 mt-1">
                          {formatTime(message.timestamp)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-8 h-8 rounded-full bg-gray-100 text-gray-600 flex items-center justify-center">
                      <Bot className="w-4 h-4" />
                    </div>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Suggested Questions */}
        {messages.length === 0 && (
          <Card className="mb-4">
            <CardHeader>
              <CardTitle className="text-sm">Suggested Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {suggestedQuestions.map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="text-left justify-start h-auto p-3 text-sm"
                    onClick={() => handleSuggestedQuestion(question)}
                    disabled={isLoading}
                  >
                    <MessageCircle className="w-3 h-3 mr-2 flex-shrink-0" />
                    {question}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask a question about your document..."
            className="flex-1"
            disabled={isLoading}
          />
          <Button 
            type="submit" 
            disabled={!inputValue.trim() || isLoading}
            className="bg-primary hover:bg-primary/90"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}