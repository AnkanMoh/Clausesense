import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { AlertTriangle, Shield, DollarSign, Calendar, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { ClauseSenseAPI } from "../utils/api";

interface SummaryData {
  documentName: string;
  summary: string;
  riskLevel: "Low" | "Medium" | "High";
  riskScore: number;
  obligations: string[];
  rights: string[];
  fees: { description: string; amount?: string }[];
  keyDates: { description: string; date: string }[];
  redFlags: string[];
}

interface SummaryViewProps {
  document: any;
}

export function SummaryView({ document }: SummaryViewProps) {
  const [summaryData, setSummaryData] = useState<SummaryData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (document?.id) {
      loadSummary();
    }
  }, [document?.id]);

  const loadSummary = async () => {
    if (!document?.id) return;

    setIsLoading(true);
    setError(null);

    try {
      const response = await ClauseSenseAPI.getSummary(document.id);
      
      setSummaryData({
        documentName: response.documentName,
        summary: response.summary.summary,
        riskLevel: response.summary.riskLevel,
        riskScore: response.summary.riskScore,
        obligations: response.summary.obligations,
        rights: response.summary.rights,
        fees: response.summary.fees,
        keyDates: response.summary.keyDates,
        redFlags: response.summary.redFlags
      });
    } catch (error) {
      console.error('Error loading summary:', error);
      if (error instanceof Error && error.message.includes('not ready')) {
        setError('Document is still being processed. Please wait a moment and try again.');
        // Retry after 3 seconds
        setTimeout(loadSummary, 3000);
      } else {
        setError('Failed to load document summary. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getRiskColor = (level: string) => {
    switch (level) {
      case "Low": return "text-green-600";
      case "Medium": return "text-yellow-600";
      case "High": return "text-red-600";
      default: return "text-gray-600";
    }
  };

  const getRiskBadgeVariant = (level: string) => {
    switch (level) {
      case "Low": return "default";
      case "Medium": return "secondary";
      case "High": return "destructive";
      default: return "outline";
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <Loader2 className="w-12 h-12 mx-auto mb-4 animate-spin text-primary" />
          <h3 className="text-lg font-medium mb-2">Analyzing Document</h3>
          <p className="text-gray-600">
            Please wait while we process your legal document...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium mb-2">Analysis Error</h3>
        <p className="text-gray-600 mb-4">{error}</p>
        <button 
          onClick={loadSummary}
          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90"
        >
          Try Again
        </button>
      </div>
    );
  }

  if (!summaryData) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <h3 className="text-lg font-medium mb-2">No Summary Available</h3>
        <p className="text-gray-600">
          Unable to load document summary. Please try again.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-2xl font-medium text-gray-900 mb-2">
          Document Summary
        </h1>
        <h2 className="text-lg text-gray-600">{summaryData.documentName}</h2>
      </div>

      {/* Summary Card */}
      <Card>
        <CardHeader>
          <CardTitle>Plain Language Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 leading-relaxed">{summaryData.summary}</p>
        </CardContent>
      </Card>

      {/* Risk Meter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Risk Assessment
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium">Overall Risk Level</span>
            <Badge variant={getRiskBadgeVariant(summaryData.riskLevel)}>
              {summaryData.riskLevel} Risk
            </Badge>
          </div>
          <Progress value={summaryData.riskScore} className="mb-2" />
          <p className="text-sm text-gray-600">
            Risk Score: {summaryData.riskScore}/100
          </p>
        </CardContent>
      </Card>

      {/* Key Information Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Obligations */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-blue-600" />
              Your Obligations
            </CardTitle>
            <CardDescription>What you're required to do</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {summaryData.obligations.map((obligation, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-2 flex-shrink-0" />
                  {obligation}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Rights */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-600" />
              Your Rights
            </CardTitle>
            <CardDescription>What you're entitled to</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {summaryData.rights.map((right, index) => (
                <li key={index} className="flex items-start gap-2 text-sm">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                  {right}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Fees */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-purple-600" />
              Fees & Costs
            </CardTitle>
            <CardDescription>Financial obligations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {summaryData.fees.map((fee, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm text-gray-700">{fee.description}</span>
                  {fee.amount && (
                    <span className="text-sm font-medium">{fee.amount}</span>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Key Dates */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-orange-600" />
              Key Dates
            </CardTitle>
            <CardDescription>Important deadlines</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {summaryData.keyDates.map((date, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm text-gray-700">{date.description}</span>
                  <span className="text-sm font-medium">{formatDate(date.date)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Red Flags */}
      <Card className="border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-700">
            <AlertTriangle className="w-5 h-5" />
            Red Flags
          </CardTitle>
          <CardDescription>Areas requiring attention</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {summaryData.redFlags.map((flag, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-red-800">{flag}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}