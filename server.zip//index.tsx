import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Initialize storage bucket on startup
async function initializeStorage() {
  const bucketName = 'make-6b2569b9-documents';
  try {
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      const { error } = await supabase.storage.createBucket(bucketName, {
        public: false,
        allowedMimeTypes: ['application/pdf'],
        fileSizeLimit: 50 * 1024 * 1024 // 50MB limit
      });
      
      if (error) {
        console.error('Error creating bucket:', error);
      } else {
        console.log('Storage bucket created successfully');
      }
    }
  } catch (error) {
    console.error('Error initializing storage:', error);
  }
}

// Initialize storage on startup
initializeStorage();

// Health check endpoint
app.get("/make-server-6b2569b9/health", (c) => {
  return c.json({ status: "ok" });
});

// Upload document endpoint
app.post("/make-server-6b2569b9/upload", async (c) => {
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }

    if (file.type !== 'application/pdf') {
      return c.json({ error: "Only PDF files are supported" }, 400);
    }

    // Generate unique document ID
    const docId = crypto.randomUUID();
    const fileName = `${docId}/${file.name}`;
    
    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('make-6b2569b9-documents')
      .upload(fileName, file);

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return c.json({ error: "Failed to upload document" }, 500);
    }

    // Store document metadata
    const documentMetadata = {
      id: docId,
      name: file.name,
      uploadDate: new Date().toISOString(),
      type: "PDF Document",
      size: file.size,
      storageKey: fileName,
      status: "uploaded"
    };

    await kv.set(`document:${docId}`, documentMetadata);
    
    // Simulate document processing (in real implementation, this would trigger AI processing)
    setTimeout(async () => {
      try {
        // Generate mock analysis data
        const analysisData = generateMockAnalysis(file.name);
        await kv.set(`analysis:${docId}`, analysisData);
        
        // Update document status
        await kv.set(`document:${docId}`, {
          ...documentMetadata,
          status: "processed"
        });
        
        console.log(`Document ${docId} processed successfully`);
      } catch (error) {
        console.error(`Error processing document ${docId}:`, error);
      }
    }, 2000);

    return c.json({ 
      documentId: docId,
      message: "Document uploaded successfully",
      metadata: documentMetadata
    });
    
  } catch (error) {
    console.error('Upload endpoint error:', error);
    return c.json({ error: "Internal server error during upload" }, 500);
  }
});

// Get document list endpoint
app.get("/make-server-6b2569b9/documents", async (c) => {
  try {
    const documents = await kv.getByPrefix("document:");
    const documentList = documents.map(doc => doc.value).sort((a, b) => 
      new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()
    );
    
    return c.json({ documents: documentList });
  } catch (error) {
    console.error('Get documents error:', error);
    return c.json({ error: "Failed to retrieve documents" }, 500);
  }
});

// Get document summary endpoint
app.get("/make-server-6b2569b9/summary/:docId", async (c) => {
  try {
    const docId = c.req.param('docId');
    
    // Check if document exists
    const document = await kv.get(`document:${docId}`);
    if (!document) {
      return c.json({ error: "Document not found" }, 404);
    }

    // Get analysis data
    const analysis = await kv.get(`analysis:${docId}`);
    if (!analysis) {
      return c.json({ error: "Document analysis not ready. Please try again later." }, 202);
    }

    return c.json({
      documentId: docId,
      documentName: document.name,
      summary: analysis
    });
    
  } catch (error) {
    console.error('Summary endpoint error:', error);
    return c.json({ error: "Failed to retrieve document summary" }, 500);
  }
});

// Ask question endpoint
app.post("/make-server-6b2569b9/ask/:docId", async (c) => {
  try {
    const docId = c.req.param('docId');
    const { question } = await c.req.json();
    
    if (!question) {
      return c.json({ error: "Question is required" }, 400);
    }

    // Check if document exists
    const document = await kv.get(`document:${docId}`);
    if (!document) {
      return c.json({ error: "Document not found" }, 404);
    }

    // Generate mock AI response (in real implementation, this would use AI)
    const response = generateMockQAResponse(question);
    
    // Store Q&A in history
    const qaId = crypto.randomUUID();
    const qaRecord = {
      id: qaId,
      documentId: docId,
      question,
      response: response.content,
      citation: response.citation,
      timestamp: new Date().toISOString()
    };
    
    await kv.set(`qa:${docId}:${qaId}`, qaRecord);

    return c.json({
      id: qaId,
      question,
      response: response.content,
      citation: response.citation,
      timestamp: qaRecord.timestamp
    });
    
  } catch (error) {
    console.error('Ask endpoint error:', error);
    return c.json({ error: "Failed to process question" }, 500);
  }
});

// Get Q&A history endpoint
app.get("/make-server-6b2569b9/qa/:docId", async (c) => {
  try {
    const docId = c.req.param('docId');
    
    const qaHistory = await kv.getByPrefix(`qa:${docId}:`);
    const history = qaHistory.map(qa => qa.value).sort((a, b) => 
      new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    return c.json({ history });
  } catch (error) {
    console.error('QA history error:', error);
    return c.json({ error: "Failed to retrieve Q&A history" }, 500);
  }
});

// Compare documents endpoint
app.post("/make-server-6b2569b9/compare", async (c) => {
  try {
    const { documentAId, documentBId } = await c.req.json();
    
    if (!documentAId || !documentBId) {
      return c.json({ error: "Both document IDs are required" }, 400);
    }

    // Check if both documents exist
    const [docA, docB] = await Promise.all([
      kv.get(`document:${documentAId}`),
      kv.get(`document:${documentBId}`)
    ]);

    if (!docA || !docB) {
      return c.json({ error: "One or both documents not found" }, 404);
    }

    // Generate mock comparison (in real implementation, this would use AI)
    const comparison = generateMockComparison(docA.name, docB.name);
    
    // Store comparison result
    const comparisonId = crypto.randomUUID();
    const comparisonRecord = {
      id: comparisonId,
      documentAId,
      documentBId,
      documentA: docA.name,
      documentB: docB.name,
      comparison,
      timestamp: new Date().toISOString()
    };
    
    await kv.set(`comparison:${comparisonId}`, comparisonRecord);

    return c.json({
      comparisonId,
      documentA: docA.name,
      documentB: docB.name,
      differences: comparison.differences,
      verdict: comparison.verdict
    });
    
  } catch (error) {
    console.error('Compare endpoint error:', error);
    return c.json({ error: "Failed to compare documents" }, 500);
  }
});

// Helper functions for generating mock data
function generateMockAnalysis(fileName: string) {
  return {
    summary: `This document "${fileName}" has been analyzed. It contains standard legal provisions with moderate risk factors. Key areas include payment terms, liability clauses, and termination conditions that require attention.`,
    riskLevel: Math.random() > 0.5 ? "Medium" : "Low",
    riskScore: Math.floor(Math.random() * 40) + 30, // 30-70 range
    obligations: [
      "Deliver services according to specifications within agreed timeframes",
      "Maintain confidentiality of sensitive information",
      "Provide regular progress reports and updates",
      "Comply with applicable laws and regulations",
      "Indemnify against third-party claims arising from services"
    ],
    rights: [
      "Receive payment according to agreed terms",
      "Retain ownership of pre-existing intellectual property", 
      "Terminate agreement under specified conditions",
      "Request reasonable changes to scope of work",
      "Access necessary resources and information"
    ],
    fees: [
      { description: "Service Fee", amount: "$" + (Math.floor(Math.random() * 100) + 50) + ",000" },
      { description: "Monthly Maintenance", amount: "$" + (Math.floor(Math.random() * 5) + 2) + ",000/month" },
      { description: "Late Payment Fee", amount: "1.5% per month" }
    ],
    keyDates: [
      { description: "Contract Start Date", date: "2024-02-01" },
      { description: "First Milestone", date: "2024-03-15" },
      { description: "Final Delivery", date: "2024-06-01" },
      { description: "Warranty Period Ends", date: "2024-09-01" }
    ],
    redFlags: [
      "Broad indemnification clause may expose significant liability",
      "Limited liability cap may not provide adequate protection",
      "Automatic renewal clause requires careful attention to notice periods"
    ]
  };
}

function generateMockQAResponse(question: string) {
  const responses = [
    {
      content: "Based on the contract analysis, the termination clause allows either party to terminate with 30 days written notice. There are also provisions for immediate termination in case of material breach.",
      citation: "Clause 12, Page 4"
    },
    {
      content: "The payment terms specify that invoices must be paid within 30 days of receipt. Late payments incur a 1.5% monthly fee on the outstanding balance.",
      citation: "Clause 7.2, Page 3"
    },
    {
      content: "Liability is limited to the total amount paid under the contract in the 12 months preceding the claim, with exceptions for gross negligence and willful misconduct.",
      citation: "Clause 9.1, Page 3"
    }
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateMockComparison(docA: string, docB: string) {
  return {
    differences: [
      {
        type: "changed",
        clause: "Clause 7.2",
        page: 3,
        description: "Payment terms modified from Net 30 to Net 15 days",
        impact: "high"
      },
      {
        type: "added",
        clause: "Clause 15",
        page: 5,
        description: "Added force majeure clause for unforeseen circumstances",
        impact: "medium"
      },
      {
        type: "removed",
        clause: "Clause 12.4",
        page: 4,
        description: "Removed automatic renewal provision",
        impact: "medium"
      }
    ],
    verdict: {
      recommendation: `Document B (${docB}) appears more favorable`,
      reasoning: "The updated version includes better protection clauses and removes potentially problematic automatic renewal terms, though payment terms are more aggressive.",
      favorability: "B"
    }
  };
}

Deno.serve(app.fetch);