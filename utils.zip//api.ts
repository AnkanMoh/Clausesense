import { projectId, publicAnonKey } from './supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-6b2569b9`;

export class ClauseSenseAPI {
  private static async makeRequest(endpoint: string, options: RequestInit = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    const defaultHeaders = {
      'Authorization': `Bearer ${publicAnonKey}`,
      'Content-Type': 'application/json',
    };

    // Don't set content-type for FormData
    const headers = options.body instanceof FormData 
      ? { 'Authorization': `Bearer ${publicAnonKey}` }
      : { ...defaultHeaders, ...options.headers };

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.error || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error(`API request failed for ${endpoint}:`, error);
      throw error;
    }
  }

  static async uploadDocument(file: File) {
    const formData = new FormData();
    formData.append('file', file);

    return this.makeRequest('/upload', {
      method: 'POST',
      body: formData,
    });
  }

  static async getDocuments() {
    return this.makeRequest('/documents');
  }

  static async getSummary(documentId: string) {
    return this.makeRequest(`/summary/${documentId}`);
  }

  static async askQuestion(documentId: string, question: string) {
    return this.makeRequest(`/ask/${documentId}`, {
      method: 'POST',
      body: JSON.stringify({ question }),
    });
  }

  static async getQAHistory(documentId: string) {
    return this.makeRequest(`/qa/${documentId}`);
  }

  static async compareDocuments(documentAId: string, documentBId: string) {
    return this.makeRequest('/compare', {
      method: 'POST',
      body: JSON.stringify({ documentAId, documentBId }),
    });
  }

  static async healthCheck() {
    return this.makeRequest('/health');
  }
}